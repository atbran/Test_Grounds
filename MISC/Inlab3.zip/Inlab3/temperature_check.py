temp_int = int(input("Please enter your integer temperature in fahrenheit : "))

if temp_int >= 70:
    print("The weather is hot")
else:
    print("The weather is cold")