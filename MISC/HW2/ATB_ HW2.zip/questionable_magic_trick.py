print("Prepare to be thoroughly entertained.")
input_int = int(input("Enter a number: "))

dynamic_int = int(input_int) * 4
print(f"Mult by 4 and get {dynamic_int}")
dynamic_int += 36
print(f"Add 36 and now we get {dynamic_int}")\

dynamic_int = dynamic_int // 4
print(f"Then we will divide by 4 and get {dynamic_int}")
dynamic_int -= input_int
print(f"Then we will subtract the original number and we will get... \n {dynamic_int}")
